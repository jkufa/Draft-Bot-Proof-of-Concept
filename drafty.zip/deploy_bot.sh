#!/bin/sh
python3 bot/main.py